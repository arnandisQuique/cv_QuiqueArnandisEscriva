package com.example.proyecto;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;

public class Inicio_Sesion
{
    @javafx.fxml.FXML
    private Text id_email;
    @javafx.fxml.FXML
    private TextField pass;
    @javafx.fxml.FXML
    private ImageView tiktok;
    @javafx.fxml.FXML
    private Text id_pass;
    @javafx.fxml.FXML
    private Button crear_cuenta;
    @javafx.fxml.FXML
    private ImageView logo;
    @javafx.fxml.FXML
    private Button inicio;
    @javafx.fxml.FXML
    private ImageView instagram;
    @javafx.fxml.FXML
    private TextField email;

    @javafx.fxml.FXML
    public void initialize() {
        System.out.println("hola fran, estoy modificando desde git");
    }

    @javafx.fxml.FXML
    public void inicio(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void crear(ActionEvent actionEvent) {
    }
}
