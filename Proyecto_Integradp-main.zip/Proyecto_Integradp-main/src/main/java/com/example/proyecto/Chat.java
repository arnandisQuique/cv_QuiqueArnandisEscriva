package com.example.proyecto;

public class Chat {
}
