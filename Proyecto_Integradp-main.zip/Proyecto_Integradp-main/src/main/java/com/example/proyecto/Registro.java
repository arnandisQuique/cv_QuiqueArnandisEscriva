package com.example.proyecto;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.text.Text;

public class Registro {
    String hola = "hola";
    @javafx.fxml.FXML
    private CheckBox Aceptar;
    @javafx.fxml.FXML
    private Text Condiciones;
    @javafx.fxml.FXML
    private Button Crear_Cuenta;

    @javafx.fxml.FXML
    public void Aceptar(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void Crear_Cuenta(ActionEvent actionEvent) {
    }
}