import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Zap, Clock, ShieldCheck } from 'lucide-react';
import { SPRINT_GROUPS } from '../constants';

const GroupsScreen: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-full bg-background-dark pb-24 text-white">
      <div className="sticky top-0 bg-background-dark/95 backdrop-blur-md z-30 pt-6 px-6 border-b border-white/5 pb-4">
          <h1 className="text-2xl font-black mb-1">Micro-Sprints</h1>
          <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Grupos de 7 días. Foco total.</p>
      </div>

      <div className="p-6 space-y-8">
        <div className="bg-surface-dark border border-dashed border-white/20 p-5 rounded-3xl text-center">
            <h3 className="text-sm font-bold mb-1">¿Tienes un código de tribu?</h3>
            <p className="text-[10px] text-gray-500 mb-4 italic">Invitación directa por mentor o compañero</p>
            <div className="flex gap-2">
                <input className="flex-1 bg-black/20 border border-white/10 rounded-xl px-4 py-2 text-sm uppercase tracking-widest font-bold" placeholder="X7-FOUNDER" />
                <button className="bg-white text-black px-4 rounded-xl font-black text-xs">UNIRME</button>
            </div>
        </div>

        <section>
            <h3 className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-4">Sprints Recomendados</h3>
            <div className="space-y-4">
                {SPRINT_GROUPS.map(group => (
                    <div 
                        key={group.id} 
                        onClick={() => navigate(`/sprint/${group.id}`)}
                        className="bg-card-dark border border-white/5 p-5 rounded-[2.5rem] relative overflow-hidden group cursor-pointer hover:border-primary/30 transition-all"
                    >
                        <div className="absolute top-0 right-0 p-4">
                            <ShieldCheck size={20} className="text-primary/40" />
                        </div>
                        <div className="flex gap-4 mb-4">
                            <img src={group.image} className="size-16 rounded-2xl object-cover" />
                            <div>
                                <h4 className="font-black text-base group-hover:text-primary transition-colors">{group.name}</h4>
                                <div className="flex items-center gap-2 mt-1">
                                    <span className="text-[9px] font-black bg-white/5 border border-white/10 px-2 py-0.5 rounded text-gray-400">S{group.sprintWeek}</span>
                                    <span className="text-[9px] font-bold text-primary flex items-center gap-1">
                                        <Zap size={10} fill="currentColor" /> {group.members}/{group.maxMembers} founders
                                    </span>
                                </div>
                            </div>
                        </div>
                        <p className="text-xs text-gray-500 mb-4 leading-relaxed">{group.description}</p>
                        <div className="flex items-center justify-between pt-4 border-t border-white/5">
                            <div className="flex items-center gap-2">
                                <Clock size={12} className="text-gray-600" />
                                <span className="text-[10px] font-bold text-gray-600">{group.daysRemaining} días</span>
                            </div>
                            <button className="bg-primary/10 text-primary border border-primary/20 px-4 py-1.5 rounded-xl font-black text-[10px] group-hover:bg-primary group-hover:text-black transition-all">VER TRIBU</button>
                        </div>
                    </div>
                ))}
            </div>
        </section>
      </div>
    </div>
  );
};

export default GroupsScreen;