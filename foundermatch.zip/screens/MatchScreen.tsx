import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Heart, Info, DollarSign, TrendingUp, Clock, Zap } from 'lucide-react';
import { BUSINESSES } from '../constants';
import { useAppContext } from '../App';

const MatchScreen: React.FC = () => {
  const navigate = useNavigate();
  const { userProfile, setUserProfile } = useAppContext();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState<'left' | 'right' | null>(null);

  const currentBusiness = BUSINESSES[currentIndex % BUSINESSES.length];

  const handleAction = (type: 'pass' | 'match') => {
    setDirection(type === 'pass' ? 'left' : 'right');
    
    // Si es match, guardamos
    if (type === 'match') {
      const alreadyInFavs = userProfile.favorites.some(f => f.id === currentBusiness.id);
      if (!alreadyInFavs) {
        setUserProfile(prev => ({
          ...prev,
          favorites: [currentBusiness, ...prev.favorites]
        }));
      }
    }

    // Animación y siguiente card
    setTimeout(() => {
      setDirection(null);
      setCurrentIndex(prev => prev + 1);
    }, 300);
  };

  return (
    <div className="flex flex-col h-full bg-background-dark relative overflow-hidden">
      <header className="flex items-center justify-between p-5 z-20">
        <div className="flex items-center gap-3">
          <div className="relative">
             <div className="bg-gradient-to-tr from-primary to-blue-500 rounded-full size-10 flex items-center justify-center text-black font-bold text-xs border-2 border-white/10">
                TÚ
             </div>
             <div className="absolute -bottom-1 -right-1 bg-primary text-[10px] font-bold text-black px-1.5 py-0.5 rounded-full border-2 border-background-dark">
               Lvl {userProfile.level}
             </div>
          </div>
          <div>
            <h2 className="text-white text-lg font-black leading-tight">Explorar Modelos</h2>
            <p className="text-primary text-[10px] font-black uppercase tracking-widest animate-pulse">
               Descubriendo oportunidades
            </p>
          </div>
        </div>
      </header>

      <div className="flex-1 px-4 pb-24 pt-2 flex items-center justify-center relative">
         {/* Animated Card Container */}
         <div className={`relative w-full max-h-[550px] aspect-[3/4.2] transition-all duration-300 transform 
            ${direction === 'left' ? '-translate-x-[150%] rotate-[-20deg] opacity-0' : ''}
            ${direction === 'right' ? 'translate-x-[150%] rotate-[20deg] opacity-0' : ''}
         `}>
            {/* Main Card */}
            <div className="w-full h-full bg-card-dark rounded-[2.5rem] overflow-hidden shadow-2xl border border-white/10 flex flex-col relative z-10">
                {/* Image Section */}
                <div className="relative h-[55%] w-full overflow-hidden">
                  <img src={currentBusiness.imageUrl} alt={currentBusiness.title} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-card-dark via-transparent to-transparent"></div>
                  
                  {/* Floating Score */}
                  <div className="absolute top-6 right-6 bg-primary text-black px-4 py-2 rounded-2xl flex items-center gap-2 shadow-neon-strong backdrop-blur-md">
                    <Zap size={16} fill="black" />
                    <span className="text-sm font-black tracking-tighter">{currentBusiness.matchScore}% Match</span>
                  </div>
                </div>

                {/* Content Section */}
                <div className="flex-1 flex flex-col p-6 gap-4">
                   <div>
                     <span className="text-[10px] font-black text-primary uppercase tracking-widest mb-1 block">{currentBusiness.category}</span>
                     <h1 className="text-2xl font-black text-white leading-tight">{currentBusiness.title}</h1>
                     <p className="text-gray-400 text-sm mt-2 leading-relaxed">{currentBusiness.description}</p>
                   </div>

                   <div className="grid grid-cols-3 gap-2 mt-auto">
                      <div className="flex flex-col gap-1 rounded-2xl bg-surface-dark p-3 items-center text-center border border-white/5">
                        <DollarSign className="text-primary size-5" />
                        <p className="text-white font-black text-xs">{currentBusiness.investment}</p>
                        <p className="text-gray-500 text-[8px] uppercase font-bold">Coste</p>
                      </div>
                      <div className="flex flex-col gap-1 rounded-2xl bg-surface-dark p-3 items-center text-center border border-white/5">
                        <TrendingUp className="text-orange-400 size-5" />
                        <p className="text-white font-black text-xs">{currentBusiness.difficulty}</p>
                        <p className="text-gray-500 text-[8px] uppercase font-bold">Reto</p>
                      </div>
                      <div className="flex flex-col gap-1 rounded-2xl bg-surface-dark p-3 items-center text-center border border-white/5">
                        <Clock className="text-blue-400 size-5" />
                        <p className="text-white font-black text-xs">{currentBusiness.timeToRevenue}</p>
                        <p className="text-gray-500 text-[8px] uppercase font-bold">Hito</p>
                      </div>
                   </div>
                </div>
            </div>
         </div>

         {/* Action Buttons */}
         <div className="absolute -bottom-6 w-full flex justify-center items-center gap-6 z-30">
            <button onClick={() => handleAction('pass')} className="group flex items-center justify-center size-16 rounded-full bg-background-dark border-4 border-surface-dark text-red-500 hover:bg-red-500 hover:text-white transition-all duration-300 shadow-xl active:scale-90">
              <X size={32} strokeWidth={4} />
            </button>
            
            <button onClick={() => navigate(`/roadmap/${currentBusiness.id}`)} className="flex items-center justify-center size-12 rounded-full bg-background-dark border-4 border-surface-dark text-blue-400 hover:bg-white/5 transition-all mb-4">
              <Info size={24} />
            </button>

            <button onClick={() => handleAction('match')} className="group flex items-center justify-center size-20 rounded-full bg-primary text-black border-4 border-background-darker shadow-neon hover:scale-110 transition-all active:scale-95">
              <Heart size={40} strokeWidth={3} fill="black" />
            </button>
         </div>
      </div>
    </div>
  );
};

export default MatchScreen;