import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ArrowRight, DollarSign, Wallet, PiggyBank, Briefcase } from 'lucide-react';
import { useAppContext } from '../App';

const QuizScreen: React.FC = () => {
  const navigate = useNavigate();
  const { quizState, setQuizState } = useAppContext();
  const [step, setStep] = useState(1);

  const handleNext = () => {
    if (step < 2) {
      setStep(step + 1);
    } else {
      // Simulate processing
      navigate('/match');
    }
  };

  const options = [
    { val: "0-100", label: "$0 - $100", sub: "Bootstrapping / Sin inversión", icon: PiggyBank },
    { val: "100-1000", label: "$100 - $1,000", sub: "Micro-negocios", icon: Wallet },
    { val: "1000-5000", label: "$1,000 - $5,000", sub: "Pequeña inversión", icon: DollarSign },
    { val: "5000+", label: "$5,000+", sub: "Inversión seria", icon: Briefcase }
  ];

  return (
    <div className="relative flex min-h-screen w-full flex-col max-w-md mx-auto bg-background-dark text-white">
      {/* Header */}
      <div className="flex flex-col w-full pt-6 px-6 z-10">
        <div className="flex items-center justify-between mb-6">
          <button 
            onClick={() => step === 1 ? navigate('/') : setStep(step - 1)} 
            className="flex items-center justify-center size-10 rounded-full hover:bg-white/10 transition-colors"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div className="text-xs font-semibold uppercase tracking-wider text-gray-500">Paso {step} de 2</div>
          <div className="size-10"></div> 
        </div>
        
        {/* Progress Bar */}
        <div className="flex w-full flex-row items-center justify-between gap-2 px-1 mb-8">
          <div className={`h-1.5 flex-1 rounded-full transition-colors duration-300 ${step >= 1 ? 'bg-primary shadow-neon' : 'bg-surface-dark'}`}></div>
          <div className={`h-1.5 flex-1 rounded-full transition-colors duration-300 ${step >= 2 ? 'bg-primary shadow-neon' : 'bg-surface-dark'}`}></div>
        </div>
      </div>

      <main className="flex-1 flex flex-col px-6 pb-28">
        {step === 1 ? (
          <>
            <div className="mb-8">
              <h1 className="text-3xl font-extrabold leading-tight mb-3">
                ¿Cuánto capital inicial tienes disponible?
              </h1>
              <p className="text-gray-400 text-base font-medium">
                Esto filtrará los negocios que no se ajusten a tu realidad actual.
              </p>
            </div>

            <div className="flex flex-col gap-4">
              {options.map((opt) => (
                <label key={opt.val} className="relative cursor-pointer group">
                  <input 
                    className="peer sr-only" 
                    name="capital" 
                    type="radio" 
                    value={opt.val}
                    checked={quizState.capital === opt.val}
                    onChange={() => setQuizState({ ...quizState, capital: opt.val })}
                  />
                  <div className="flex items-center p-4 rounded-2xl bg-surface-dark border-2 border-transparent peer-checked:border-primary/50 peer-checked:bg-primary/10 hover:border-white/10 transition-all duration-300">
                    <div className={`flex items-center justify-center size-12 rounded-xl shrink-0 mr-4 transition-colors ${quizState.capital === opt.val ? 'bg-primary text-black' : 'bg-white/5 text-gray-400'}`}>
                      <opt.icon className="w-6 h-6" />
                    </div>
                    <div className="flex flex-col flex-1 mr-2">
                      <span className={`text-lg font-bold ${quizState.capital === opt.val ? 'text-primary' : 'text-white'}`}>{opt.label}</span>
                      <span className="text-sm font-medium text-gray-500">{opt.sub}</span>
                    </div>
                    <div className={`size-6 rounded-full border-2 flex items-center justify-center ${quizState.capital === opt.val ? 'border-primary' : 'border-gray-600'}`}>
                      {quizState.capital === opt.val && <div className="size-3 bg-primary rounded-full" />}
                    </div>
                  </div>
                </label>
              ))}
            </div>
          </>
        ) : (
          <>
             <div className="mb-8">
              <h1 className="text-3xl font-extrabold leading-tight mb-3">
                ¿Qué disponibilidad de tiempo tienes?
              </h1>
              <p className="text-gray-400 text-base font-medium">
                Algunos negocios requieren atención 24/7, otros son más pasivos.
              </p>
            </div>

            <div className="flex flex-col gap-4">
               {['Solo fines de semana', '1-2 horas al día', 'Medio tiempo', 'Tiempo completo'].map((time) => (
                <label key={time} className="relative cursor-pointer group">
                  <input 
                    className="peer sr-only" 
                    name="time" 
                    type="radio" 
                    value={time}
                    checked={quizState.timeCommitment === time}
                    onChange={() => setQuizState({ ...quizState, timeCommitment: time })}
                  />
                  <div className="flex items-center p-5 rounded-2xl bg-surface-dark border-2 border-transparent peer-checked:border-primary/50 peer-checked:bg-primary/10 hover:border-white/10 transition-all duration-300">
                     <div className="flex flex-col flex-1">
                      <span className={`text-lg font-bold ${quizState.timeCommitment === time ? 'text-primary' : 'text-white'}`}>{time}</span>
                    </div>
                    {quizState.timeCommitment === time && <div className="text-primary font-bold">Seleccionado</div>}
                  </div>
                </label>
               ))}
            </div>
          </>
        )}
      </main>

      {/* Sticky Footer */}
      <footer className="fixed bottom-0 left-0 right-0 max-w-md mx-auto p-6 bg-gradient-to-t from-background-dark via-background-dark to-transparent z-20">
        <button 
          onClick={handleNext} 
          className="w-full bg-primary hover:bg-[#3bd60f] text-black font-extrabold text-lg py-4 rounded-full shadow-neon active:scale-[0.98] transition-all transform flex items-center justify-center gap-2"
        >
          {step === 2 ? 'Encontrar mi Match' : 'Continuar'}
          <ArrowRight className="w-5 h-5" />
        </button>
      </footer>
    </div>
  );
};

export default QuizScreen;