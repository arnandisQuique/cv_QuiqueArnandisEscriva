import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, CheckCircle2, Play, AlertCircle, MessageCircle, ChevronRight, Lock, Verified } from 'lucide-react';
import { BUSINESSES, ROADMAP_COMMENTS } from '../constants';

const RoadmapScreen: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const business = BUSINESSES.find(b => b.id === id) || BUSINESSES[0];
  const [isTaskDone, setIsTaskDone] = useState(false);
  const [showBlockedModal, setShowBlockedModal] = useState(false);

  return (
    <div className="min-h-screen bg-background-darker text-white pb-12">
      <header className="sticky top-0 z-50 flex items-center justify-between px-5 py-4 bg-background-darker/90 backdrop-blur-md border-b border-white/5">
        <button onClick={() => navigate('/match')} className="flex items-center justify-center w-10 h-10 rounded-full hover:bg-white/10 transition-colors">
          <ArrowLeft className="text-white w-6 h-6" />
        </button>
        <h1 className="text-sm font-black tracking-tight uppercase text-gray-400">{business.title}</h1>
        <div className="bg-primary/10 px-3 py-1 rounded-full border border-primary/20">
           <span className="text-[10px] font-black text-primary">S1</span>
        </div>
      </header>

      <div className="p-6 space-y-6">
        <div className="bg-surface-dark border border-white/10 rounded-3xl p-6 relative overflow-hidden">
            <div className="flex justify-between items-start mb-4">
                <span className="text-[10px] font-black text-primary bg-primary/20 px-2 py-1 rounded">MISIÓN 1.2</span>
                <button onClick={() => setShowBlockedModal(true)} className="flex items-center gap-1.5 text-xs font-bold text-orange-400">
                    <AlertCircle size={14} /> Bloqueado
                </button>
            </div>
            <h2 className="text-2xl font-black mb-2">Análisis de Mercado B2B</h2>
            <p className="text-gray-400 text-sm mb-6 leading-relaxed">Encuentra 10 perfiles de LinkedIn que encajen con tu oferta. Anota sus nombres.</p>
            
            <div className="flex gap-3">
                <button className="flex-1 bg-white/5 border border-white/10 text-white font-bold py-3 rounded-2xl text-sm flex items-center justify-center gap-2">
                    <Play size={14} fill="white" /> Guía
                </button>
                <button 
                    onClick={() => setIsTaskDone(!isTaskDone)} 
                    className={`flex-1 font-black py-3 rounded-2xl text-sm transition-all shadow-neon ${isTaskDone ? 'bg-primary text-black' : 'bg-primary/10 text-primary border border-primary/30'}`}
                >
                    {isTaskDone ? 'Completado ✓' : 'Marcar Hecho'}
                </button>
            </div>
        </div>

        {/* Contextual Feedback Section */}
        <section>
            <div className="flex items-center justify-between mb-4">
                <h3 className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Consejos de la Tribu</h3>
                <span className="text-[9px] text-gray-600 font-bold uppercase">Max 3 Recientes</span>
            </div>
            
            <div className="relative space-y-3">
                {!isTaskDone && (
                    <div className="absolute inset-0 z-10 bg-background-darker/60 backdrop-blur-sm rounded-2xl flex flex-col items-center justify-center p-6 text-center border border-white/5">
                        <Lock size={24} className="text-gray-500 mb-2" />
                        <p className="text-xs font-bold text-gray-400">Completa la tarea para ver los consejos y validar.</p>
                    </div>
                )}
                
                {ROADMAP_COMMENTS.map((comment) => (
                    <div key={comment.id} className="bg-card-dark border border-white/5 p-4 rounded-2xl flex gap-3">
                        <img src={comment.avatar} className="size-8 rounded-xl object-cover" />
                        <div className="flex-1">
                            <div className="flex items-center gap-1.5 mb-1">
                                <span className="text-[10px] font-black text-gray-300">{comment.userName}</span>
                                {comment.isMentor && <Verified size={10} className="text-blue-400 fill-blue-400/20" />}
                                <span className="text-[9px] text-gray-600 ml-auto">{comment.timestamp}</span>
                            </div>
                            <p className="text-xs text-gray-400 leading-normal">{comment.text}</p>
                        </div>
                    </div>
                ))}
            </div>
            
            {isTaskDone && (
                <button className="w-full mt-4 py-3 text-xs font-black text-primary bg-primary/5 rounded-2xl border border-primary/10 flex items-center justify-center gap-2">
                    <MessageCircle size={14} /> Añadir mi aprendizaje
                </button>
            )}
        </section>

        <section>
            <h3 className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-4">Tu progreso</h3>
            <div className="space-y-3">
                {[1, 2, 3].map((step) => (
                    <div key={step} className={`flex items-center gap-4 p-4 rounded-2xl border transition-all ${step === 2 ? 'bg-surface-dark border-primary/40' : 'bg-card-dark/40 border-white/5 opacity-40'}`}>
                        <div className={`size-8 rounded-xl border-2 flex items-center justify-center text-xs font-black ${step < 2 ? 'bg-primary border-primary text-black' : 'border-white/10 text-gray-500'}`}>
                            {step < 2 ? '✓' : step}
                        </div>
                        <div className="flex-1">
                            <p className="text-sm font-bold">{step === 1 ? 'Nicho' : step === 2 ? 'Competencia' : 'Oferta Irresistible'}</p>
                        </div>
                        {step === 2 && <ChevronRight size={16} className="text-primary" />}
                    </div>
                ))}
            </div>
        </section>
      </div>

      {/* Blocked Modal (simplified) */}
      {showBlockedModal && (
        <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-center justify-center p-6">
            <div className="bg-card-dark w-full rounded-3xl p-6 border border-orange-500/30">
                <h3 className="text-xl font-black mb-2 text-orange-400">¿Bloqueo real?</h3>
                <p className="text-gray-400 text-sm mb-6 leading-relaxed">No te pares. Describe qué te falta y un mentor te desbloqueará en menos de 2h.</p>
                <textarea className="w-full bg-surface-dark border border-white/10 rounded-2xl p-4 text-sm focus:border-primary focus:outline-none mb-4" rows={3} placeholder="Me falta..." />
                <div className="flex gap-3">
                    <button onClick={() => setShowBlockedModal(false)} className="flex-1 py-3 text-sm font-bold text-gray-500">Cancelar</button>
                    <button onClick={() => setShowBlockedModal(false)} className="flex-1 py-3 text-sm font-black bg-orange-500 rounded-2xl">Pedir Ayuda</button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default RoadmapScreen;