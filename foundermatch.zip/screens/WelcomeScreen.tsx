import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Rocket, ArrowRight, Zap } from 'lucide-react';

const WelcomeScreen: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="relative flex h-full min-h-screen w-full flex-col overflow-x-hidden max-w-md mx-auto bg-background-dark text-white">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-[60%] bg-gradient-to-b from-[#1c2e18] to-transparent opacity-50 z-0 pointer-events-none" />
      <div className="absolute -top-20 -right-20 w-64 h-64 bg-primary rounded-full blur-[120px] opacity-20 pointer-events-none" />

      {/* Header */}
      <div className="flex items-center p-6 justify-between z-10">
        <div className="flex size-10 items-center justify-center rounded-full bg-white/5 border border-white/10 backdrop-blur-sm">
          <Rocket className="text-primary h-5 w-5" />
        </div>
        <button className="text-sm font-bold text-gray-400 hover:text-primary transition-colors">
          Iniciar Sesión
        </button>
      </div>

      <div className="flex-1 flex flex-col justify-center px-6 pb-12 z-10 relative">
        {/* Hero Image */}
        <div className="w-full relative mb-10 group">
          <div className="absolute -inset-0.5 bg-gradient-to-r from-primary to-emerald-600 rounded-2xl blur opacity-30 group-hover:opacity-50 transition duration-1000"></div>
          <div className="relative w-full aspect-[4/5] rounded-xl overflow-hidden shadow-2xl">
            <img 
              src="https://images.unsplash.com/photo-1559136555-9303baea8ebd?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
              alt="Founder" 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background-dark via-transparent to-transparent opacity-90"></div>
            
            {/* Floating Badge */}
            <div className="absolute bottom-6 left-6 right-6">
                <div className="bg-white/10 backdrop-blur-md border border-white/10 p-4 rounded-xl">
                    <div className="flex items-center gap-3">
                        <div className="size-10 rounded-full bg-primary/20 flex items-center justify-center">
                            <Zap className="text-primary size-5 fill-current" />
                        </div>
                        <div>
                            <p className="text-xs text-gray-300 uppercase font-semibold tracking-wider">Comunidad Gratis</p>
                            <p className="text-white font-bold text-sm">+1,200 Founders Activos</p>
                        </div>
                    </div>
                </div>
            </div>
          </div>
        </div>

        {/* Text */}
        <div className="flex flex-col items-center text-center space-y-5">
          <div className="inline-flex items-center px-3 py-1 rounded-full border border-primary/30 bg-primary/10 text-primary text-xs font-bold uppercase tracking-wider shadow-neon">
            100% Gratis
          </div>
          <h1 className="text-4xl font-extrabold leading-tight tracking-tight">
            Encuentra tu <span className="text-primary relative">
               Match
               <svg className="absolute w-full h-3 -bottom-1 left-0 text-primary opacity-40" viewBox="0 0 100 10" preserveAspectRatio="none">
                 <path d="M0 5 Q 50 10 100 5" stroke="currentColor" strokeWidth="3" fill="none" />
               </svg>
            </span> de Negocio
          </h1>
          <p className="text-gray-400 text-lg font-medium leading-relaxed max-w-[320px]">
            Conecta con ideas rentables y únete a grupos de gente con tu misma ambición.
          </p>
        </div>

        <div className="h-8"></div>

        {/* CTA */}
        <button 
          onClick={() => navigate('/quiz')} 
          className="group relative w-full flex cursor-pointer items-center justify-center overflow-hidden rounded-full h-14 bg-primary text-background-dark text-lg font-bold transition-all hover:scale-[1.02] active:scale-[0.98] shadow-neon-strong"
        >
          <span className="relative z-10 flex items-center gap-2">
            Comenzar Ahora
            <ArrowRight className="w-5 h-5" />
          </span>
        </button>
      </div>
    </div>
  );
};

export default WelcomeScreen;