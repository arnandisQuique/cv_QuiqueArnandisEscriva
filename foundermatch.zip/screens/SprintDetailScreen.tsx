import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, MessageSquare, Zap, Clock, ShieldCheck, Verified } from 'lucide-react';
import { SPRINT_GROUPS } from '../constants';

const SprintDetailScreen: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const sprint = SPRINT_GROUPS.find(s => s.id === id) || SPRINT_GROUPS[0];

  return (
    <div className="min-h-full bg-background-darker text-white pb-24">
      {/* Header */}
      <div className="p-6 flex items-center gap-4 border-b border-white/5 bg-background-darker/80 backdrop-blur-md sticky top-0 z-40">
        <button onClick={() => navigate('/groups')} className="size-10 rounded-full bg-surface-dark flex items-center justify-center">
            <ArrowLeft size={20} />
        </button>
        <div>
            <h1 className="text-lg font-black">{sprint.name}</h1>
            <p className="text-[10px] font-bold text-primary uppercase">Misión: 3 Clientes B2B</p>
        </div>
      </div>

      <div className="p-6 space-y-6">
          {/* Sprint Status Card */}
          <div className="bg-surface-dark border border-primary/20 p-5 rounded-3xl flex justify-between items-center shadow-glow">
              <div className="flex flex-col">
                  <span className="text-[10px] font-black text-gray-500 uppercase">Tiempo Restante</span>
                  <div className="flex items-center gap-2 mt-1">
                      <Clock size={16} className="text-primary" />
                      <span className="text-xl font-black">{sprint.daysRemaining} Días</span>
                  </div>
              </div>
              <div className="h-12 w-px bg-white/10" />
              <div className="flex flex-col items-end">
                  <span className="text-[10px] font-black text-gray-500 uppercase">Fase de Tribu</span>
                  <span className="text-sm font-black text-primary mt-1">S{sprint.sprintWeek}: Validación</span>
              </div>
          </div>

          {/* Members List */}
          <section>
              <h3 className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-4">Tribu ({sprint.tribeMembers.length}/7)</h3>
              <div className="space-y-3">
                  {sprint.tribeMembers.map(member => (
                      <div key={member.id} className="bg-card-dark border border-white/5 p-4 rounded-3xl flex items-center gap-4 hover:border-white/20 transition-all">
                          <div className="relative">
                            <img src={member.avatar} className="size-12 rounded-2xl object-cover" />
                            {member.isMentor && (
                                <div className="absolute -top-1 -right-1 bg-blue-500 p-0.5 rounded-full border-2 border-card-dark">
                                    <Verified size={10} className="text-white fill-white/20" />
                                </div>
                            )}
                          </div>
                          <div className="flex-1">
                              <div className="flex items-center gap-2">
                                <h4 className="text-sm font-black">{member.name}</h4>
                                {member.isMentor && <span className="text-[8px] font-black text-blue-400 bg-blue-400/10 px-1.5 py-0.5 rounded">MENTOR</span>}
                              </div>
                              <p className="text-[10px] font-bold text-gray-500 mt-0.5">{member.currentState}</p>
                          </div>
                          <button className="p-3 bg-white/5 rounded-2xl text-gray-400 hover:text-primary transition-colors">
                              <MessageSquare size={18} />
                          </button>
                      </div>
                  ))}
                  
                  {/* Empty slots */}
                  {Array.from({ length: 7 - sprint.tribeMembers.length }).map((_, i) => (
                      <div key={i} className="bg-black/20 border border-dashed border-white/5 p-4 rounded-3xl flex items-center justify-center text-gray-600">
                          <span className="text-[10px] font-black uppercase italic">Puesto Disponible</span>
                      </div>
                  ))}
              </div>
          </section>

          {/* Team Rules */}
          <div className="bg-card-dark border border-white/5 p-5 rounded-3xl">
              <div className="flex items-center gap-2 mb-3 text-primary">
                  <ShieldCheck size={16} />
                  <h4 className="text-[10px] font-black uppercase">Código de Tribu</h4>
              </div>
              <ul className="space-y-2">
                  <li className="text-[10px] text-gray-500 flex gap-2">
                      <span className="text-primary font-bold">1.</span>
                      Participar diariamente en el feedback del roadmap.
                  </li>
                  <li className="text-[10px] text-gray-500 flex gap-2">
                      <span className="text-primary font-bold">2.</span>
                      Compartir fracasos y métricas reales. No posteo de humo.
                  </li>
              </ul>
          </div>
      </div>
    </div>
  );
};

export default SprintDetailScreen;