import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Lightbulb, Users, Trophy, ArrowRight, MessageSquare, BookOpen, UserPlus } from 'lucide-react';
import { useAppContext } from '../App';
import { PostStructureType } from '../types';

const CreateScreen: React.FC = () => {
  const navigate = useNavigate();
  const { userProfile, setUserProfile } = useAppContext();
  const [type, setType] = useState<PostStructureType>('Feedback');
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
      title: '',
      what: '',
      goal: '',
      learning: '',
      step: 'Semana 1'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newPost = {
        id: Date.now().toString(),
        type,
        title: formData.title,
        content: type === 'Learning' ? formData.learning : formData.what,
        context: formData.step,
        reactions: { unblocked: 0, tried: 0, valuable: 0 },
        timestamp: 'Ahora'
    };

    setUserProfile(prev => ({
      ...prev,
      myPosts: [newPost, ...prev.myPosts],
      xp: prev.xp + 50
    }));

    navigate('/explore');
  };

  return (
    <div className="min-h-screen bg-background-darker text-white flex flex-col">
      <div className="flex items-center justify-between p-6">
        <button onClick={() => navigate(-1)} className="size-10 rounded-full bg-surface-dark flex items-center justify-center"><X size={20} /></button>
        <h1 className="text-xs font-black uppercase tracking-widest text-gray-500">Publicar Acción</h1>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 px-6 pb-12 overflow-y-auto">
        {step === 1 ? (
            <div className="space-y-4 flex flex-col justify-center h-full">
                 <h2 className="text-3xl font-black mb-4">¿Cuál es tu objetivo?</h2>
                 <div className="grid grid-cols-1 gap-3">
                     {[
                         { id: 'Feedback', label: 'Busco Feedback', sub: 'Acción + duda concreta', icon: MessageSquare, color: 'text-blue-400' },
                         { id: 'Partner', label: 'Busco Compañero', sub: 'Paso específico + tiempo', icon: UserPlus, color: 'text-purple-400' },
                         { id: 'Learning', label: 'Aprendizaje Real', sub: 'Qué intenté + qué falló', icon: BookOpen, color: 'text-green-400' }
                     ].map((item) => (
                        <button 
                            key={item.id}
                            onClick={() => { setType(item.id as PostStructureType); setStep(2); }}
                            className="flex items-center p-5 bg-card-dark border border-white/5 rounded-3xl hover:border-primary/50 transition-all text-left group"
                        >
                            <div className={`size-12 rounded-2xl bg-white/5 flex items-center justify-center mr-4 ${item.color} group-hover:scale-110 transition-transform`}>
                                <item.icon size={24} />
                            </div>
                            <div>
                                <h3 className="text-lg font-black">{item.label}</h3>
                                <p className="text-xs text-gray-500">{item.sub}</p>
                            </div>
                        </button>
                     ))}
                 </div>
            </div>
        ) : (
            <form onSubmit={handleSubmit} className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
                <div className="bg-primary/10 border border-primary/20 p-4 rounded-2xl flex items-center justify-between">
                    <div>
                        <p className="text-[10px] font-black text-primary uppercase">Estructura</p>
                        <p className="text-sm font-bold">{type === 'Feedback' ? 'Contexto + Acción + Duda' : type === 'Partner' ? 'Sprint de 7 días' : 'Análisis post-acción'}</p>
                    </div>
                    <button type="button" onClick={() => setStep(1)} className="text-xs text-gray-500 underline font-bold">Cambiar</button>
                </div>

                <div className="space-y-4">
                    <div>
                        <label className="text-[10px] font-black text-gray-500 uppercase mb-2 block">Título de la acción</label>
                        <input 
                            required
                            className="w-full bg-surface-dark border border-white/10 rounded-2xl p-4 text-sm focus:border-primary focus:outline-none"
                            placeholder="Ej: Validando nicho con 20 emails"
                            value={formData.title}
                            onChange={e => setFormData({...formData, title: e.target.value})}
                        />
                    </div>

                    {type === 'Feedback' && (
                        <>
                            <div>
                                <label className="text-[10px] font-black text-gray-500 uppercase mb-2 block">¿Qué has hecho exactamente?</label>
                                <textarea required className="w-full bg-surface-dark border border-white/10 rounded-2xl p-4 text-sm focus:border-primary focus:outline-none" rows={3} placeholder="Describe tu acción..." onChange={e => setFormData({...formData, what: e.target.value})} />
                            </div>
                            <div>
                                <label className="text-[10px] font-black text-gray-500 uppercase mb-2 block">Duda concreta</label>
                                <input required className="w-full bg-surface-dark border border-white/10 rounded-2xl p-4 text-sm focus:border-primary focus:outline-none" placeholder="¿Cuál es tu obstáculo?" />
                            </div>
                        </>
                    )}

                    {type === 'Learning' && (
                        <div>
                            <label className="text-[10px] font-black text-gray-500 uppercase mb-2 block">¿Qué ha salido mal y qué harás distinto?</label>
                            <textarea required className="w-full bg-surface-dark border border-white/10 rounded-2xl p-4 text-sm focus:border-primary focus:outline-none" rows={5} placeholder="Sé honesto, aquí no hay humos." onChange={e => setFormData({...formData, learning: e.target.value})} />
                        </div>
                    )}
                </div>

                <button type="submit" className="w-full bg-primary text-black font-black py-5 rounded-3xl shadow-neon flex items-center justify-center gap-2 text-lg active:scale-95 transition-transform">
                    PUBLICAR ACCIÓN <ArrowRight size={20} />
                </button>
            </form>
        )}
      </div>
    </div>
  );
};

export default CreateScreen;