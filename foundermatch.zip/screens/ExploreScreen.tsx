import React from 'react';
import { TrendingUp, MessageCircle, MoreHorizontal, Zap, Layers, Rocket, Users } from 'lucide-react';
import { SUCCESS_STORIES, SPRINT_GROUPS } from '../constants';

const ExploreScreen: React.FC = () => {
  return (
    <div className="min-h-full bg-background-dark pb-24 text-white">
      <header className="sticky top-0 bg-background-dark/95 backdrop-blur-md z-30 pt-6 pb-4 border-b border-white/5 px-6">
        <h1 className="text-2xl font-black mb-1">Muro de Acción</h1>
        <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Inspiración basada en hechos</p>
      </header>

      <div className="p-4 space-y-6">
        {/* Active Sprints (Micro-Groups) */}
        <section>
            <div className="flex items-center gap-2 mb-4">
                <Users size={16} className="text-primary" />
                <h3 className="text-xs font-black uppercase tracking-tighter">Sprints de 7 días</h3>
            </div>
            <div className="flex gap-4 overflow-x-auto no-scrollbar pb-2">
                {SPRINT_GROUPS.map(sprint => (
                    <div key={sprint.id} className="shrink-0 w-64 bg-surface-dark border border-white/10 p-4 rounded-3xl">
                        <div className="flex justify-between mb-3">
                            <span className="text-[9px] font-black text-primary bg-primary/10 px-2 py-0.5 rounded uppercase">SEMANA {sprint.sprintWeek}</span>
                            <span className="text-[9px] font-bold text-gray-500 uppercase">{sprint.daysRemaining} días rest.</span>
                        </div>
                        <h4 className="font-bold text-sm mb-1">{sprint.name}</h4>
                        <p className="text-[10px] text-gray-500 mb-4">{sprint.description}</p>
                        <div className="flex items-center justify-between">
                            <div className="flex -space-x-1">
                                {[1, 2, 3].map(i => (
                                    <div key={i} className="size-5 rounded-full bg-gray-600 border border-surface-dark" />
                                ))}
                            </div>
                            <button className="text-[10px] font-black bg-white text-black px-3 py-1 rounded-lg">UNIRME</button>
                        </div>
                    </div>
                ))}
            </div>
        </section>

        {/* Action Feed */}
        <div className="space-y-4">
            {SUCCESS_STORIES.map((story) => (
                <div key={story.id} className="bg-card-dark border border-white/5 rounded-3xl p-5 shadow-lg relative">
                    <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-3">
                            <img src={story.user.avatar} className="size-9 rounded-2xl object-cover" />
                            <div>
                                <h4 className="text-xs font-black leading-none">{story.user.name}</h4>
                                <span className="text-[10px] text-gray-600">Semana 4 • Agencia</span>
                            </div>
                        </div>
                        <button className="text-gray-600"><MoreHorizontal size={16} /></button>
                    </div>

                    <div className="mb-4">
                        <h2 className="text-base font-bold mb-2 leading-tight">{story.title}</h2>
                        <p className="text-sm text-gray-400 leading-relaxed line-clamp-3">{story.description}</p>
                    </div>

                    {/* Action Stats (Anti-Like) */}
                    <div className="flex gap-2 mb-4">
                        <div className="bg-surface-dark px-3 py-2 rounded-xl flex items-center gap-2 border border-white/5">
                            <TrendingUp size={14} className="text-green-400" />
                            <div className="flex flex-col">
                                <span className="text-xs font-black text-white">{story.metric}</span>
                                <span className="text-[8px] font-bold text-gray-600 uppercase tracking-tighter">{story.metricLabel}</span>
                            </div>
                        </div>
                    </div>

                    {/* Qualitative Reactions */}
                    <div className="pt-4 border-t border-white/5 flex items-center justify-between">
                        <div className="flex gap-3">
                            <button className="flex flex-col items-center gap-1 group">
                                <div className="size-8 rounded-xl bg-white/5 flex items-center justify-center group-hover:bg-primary/20 transition-all">
                                    <Zap size={14} className="text-primary" />
                                </div>
                                <span className="text-[8px] font-bold text-gray-500">ME DESBLOQUEÓ</span>
                            </button>
                            <button className="flex flex-col items-center gap-1 group">
                                <div className="size-8 rounded-xl bg-white/5 flex items-center justify-center group-hover:bg-blue-400/20 transition-all">
                                    <Layers size={14} className="text-blue-400" />
                                </div>
                                <span className="text-[8px] font-bold text-gray-500">LO INTENTARÉ</span>
                            </button>
                        </div>
                        <button className="flex items-center gap-1.5 text-gray-500 hover:text-white transition-colors">
                            <MessageCircle size={16} />
                            <span className="text-[10px] font-bold">{story.commentsCount}</span>
                        </button>
                    </div>
                </div>
            ))}
        </div>
      </div>
    </div>
  );
};

export default ExploreScreen;