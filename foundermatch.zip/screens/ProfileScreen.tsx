
import React, { useState } from 'react';
// Added useNavigate import
import { useNavigate } from 'react-router-dom';
import { Settings, Share2, Award, Zap, Shield, X, Camera, Layout, Heart, Target, ToggleLeft, ToggleRight, MessageSquareOff, Check, Edit3 } from 'lucide-react';
import { useAppContext } from '../App';
import { BADGES } from '../constants';

const ProfileScreen: React.FC = () => {
  // Initialized navigate hook
  const navigate = useNavigate();
  const { userProfile, setUserProfile } = useAppContext();
  const [isEditing, setIsEditing] = useState(false);
  const [activeTab, setActiveTab] = useState<'posts' | 'favorites'>('posts');
  
  // Local edit state
  const [editData, setEditData] = useState({
    name: userProfile.name,
    bio: userProfile.bio,
    currentState: userProfile.currentState,
    availability: userProfile.availability
  });

  const handleSave = () => {
    setUserProfile(prev => ({
      ...prev,
      ...editData
    }));
    setIsEditing(false);
  };

  return (
    <div className="min-h-full bg-background-dark pb-32 text-white">
      {/* Cover / Header */}
      <div className="relative h-44 bg-gradient-to-br from-surface-dark to-background-dark border-b border-white/5 p-6 flex items-end">
        <div className="absolute top-4 right-4 flex gap-2">
             <button 
                onClick={() => isEditing ? handleSave() : setIsEditing(true)} 
                className={`p-2 backdrop-blur rounded-full border border-white/10 transition-all ${isEditing ? 'bg-primary text-black border-primary' : 'bg-black/40 text-white'}`}
             >
                {isEditing ? <Check size={18} strokeWidth={3} /> : <Edit3 size={18} />}
             </button>
             {!isEditing && (
                 <button className="p-2 bg-black/40 backdrop-blur rounded-full border border-white/10">
                    <Share2 size={18} />
                 </button>
             )}
        </div>
        
        {!isEditing && userProfile.dailyNote && (
            <div className="w-full bg-primary/10 border border-primary/20 backdrop-blur-md p-3 rounded-2xl relative animate-in fade-in slide-in-from-bottom-2">
                <span className="absolute -top-2 left-4 px-2 py-0.5 bg-primary text-black text-[8px] font-black uppercase rounded">Nota del día</span>
                <p className="text-xs italic text-primary/90 font-medium">"{userProfile.dailyNote}"</p>
            </div>
        )}
      </div>

      <div className="px-6 relative -mt-10 mb-6">
        <div className="flex items-end justify-between mb-4">
            <div className="relative group">
                <div className="size-24 rounded-[2rem] bg-surface-dark p-1 border-4 border-primary shadow-neon overflow-hidden">
                    <img src={userProfile.avatar} alt="Profile" className="w-full h-full object-cover rounded-[1.7rem]" />
                    {isEditing && (
                        <div className="absolute inset-0 bg-black/60 flex items-center justify-center cursor-pointer">
                            <Camera size={24} className="text-white" />
                        </div>
                    )}
                </div>
            </div>

            <div className="flex gap-4 pb-2">
                 <div className="text-center">
                    <p className="text-xl font-black leading-none">{userProfile.streak}</p>
                    <p className="text-[9px] font-bold text-gray-500 uppercase">Racha</p>
                 </div>
                 <div className="text-center">
                    <p className="text-xl font-black leading-none">{userProfile.level}</p>
                    <p className="text-[9px] font-bold text-gray-500 uppercase">Lvl</p>
                 </div>
            </div>
        </div>

        {/* Info / Edit Fields */}
        <div className="space-y-3">
            {isEditing ? (
                <div className="space-y-4 bg-surface-dark p-4 rounded-3xl border border-white/10">
                    <div>
                        <label className="text-[9px] font-black text-gray-500 uppercase mb-1 block">Nombre</label>
                        <input 
                            className="w-full bg-black/20 border border-white/10 rounded-xl px-3 py-2 text-sm font-bold focus:border-primary outline-none"
                            value={editData.name}
                            onChange={e => setEditData({...editData, name: e.target.value})}
                        />
                    </div>
                    <div>
                        <label className="text-[9px] font-black text-gray-500 uppercase mb-1 block">Fase Actual</label>
                        <input 
                            className="w-full bg-black/20 border border-white/10 rounded-xl px-3 py-2 text-sm font-bold focus:border-primary outline-none"
                            value={editData.currentState}
                            onChange={e => setEditData({...editData, currentState: e.target.value})}
                        />
                    </div>
                    <div>
                        <label className="text-[9px] font-black text-gray-500 uppercase mb-1 block">Biografía Corta</label>
                        <textarea 
                            className="w-full bg-black/20 border border-white/10 rounded-xl px-3 py-2 text-xs focus:border-primary outline-none"
                            value={editData.bio}
                            rows={3}
                            onChange={e => setEditData({...editData, bio: e.target.value})}
                        />
                    </div>
                </div>
            ) : (
                <>
                    <h1 className="text-2xl font-black flex items-center gap-2">
                        {userProfile.name}
                        <Shield size={16} className="text-blue-400 fill-current" />
                    </h1>
                    <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 bg-primary/10 border border-primary/20 rounded text-[10px] font-black text-primary uppercase">
                            {userProfile.currentState}
                        </span>
                        <span className="text-[10px] text-gray-500 font-bold tracking-tight">Semana 2 de 12</span>
                    </div>
                    <p className="text-sm text-gray-400 leading-relaxed mt-2">{userProfile.bio}</p>
                </>
            )}
        </div>

        {/* Action Toggles */}
        <div className="mt-6 p-4 bg-surface-dark border border-white/5 rounded-[2rem] space-y-3">
             <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                    <Target size={16} className="text-primary" />
                    <span className="text-xs font-bold text-gray-300">Abierto a Feedback</span>
                </div>
                <ToggleRight className="text-primary cursor-pointer" />
             </div>
             <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                    <MessageSquareOff size={16} className="text-gray-500" />
                    <span className="text-xs font-bold text-gray-500">DM Filtro Mentor</span>
                </div>
                <ToggleLeft className="text-gray-600" />
             </div>
        </div>
      </div>

      {/* Badges */}
      <div className="px-6 mb-8">
        <h3 className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-4">Logros Reales</h3>
        <div className="grid grid-cols-4 gap-4">
            {BADGES.map(badge => {
                const isUnlocked = userProfile.badges.some(b => b.id === badge.id);
                return (
                    <div key={badge.id} className={`flex flex-col items-center gap-2 transition-all ${isUnlocked ? 'opacity-100' : 'opacity-20'}`}>
                        <div className="size-14 rounded-2xl bg-surface-dark border border-white/10 flex items-center justify-center text-2xl shadow-lg">
                            {badge.icon}
                        </div>
                        <span className="text-[9px] font-black text-center leading-tight uppercase tracking-tighter">{badge.label}</span>
                    </div>
                );
            })}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex px-6 border-b border-white/5 mb-6">
          <button 
            onClick={() => setActiveTab('posts')}
            className={`flex-1 pb-3 text-xs font-black relative transition-all ${activeTab === 'posts' ? 'text-primary' : 'text-gray-500'}`}
          >
            ACTIVIDAD
            {activeTab === 'posts' && <div className="absolute bottom-0 left-0 w-full h-1 bg-primary shadow-neon rounded-t-full"></div>}
          </button>
          <button 
            onClick={() => setActiveTab('favorites')}
            className={`flex-1 pb-3 text-xs font-black relative transition-all ${activeTab === 'favorites' ? 'text-primary' : 'text-gray-500'}`}
          >
            FAVORITOS
            {activeTab === 'favorites' && <div className="absolute bottom-0 left-0 w-full h-1 bg-primary shadow-neon rounded-t-full"></div>}
          </button>
      </div>

      <div className="px-6 space-y-4">
          {activeTab === 'posts' ? (
              userProfile.myPosts.map(post => (
                  <div key={post.id} className="bg-card-dark border border-white/5 p-5 rounded-3xl animate-in fade-in slide-in-from-bottom-2">
                      <div className="flex items-center justify-between mb-3">
                          <span className="text-[9px] font-black text-primary bg-primary/10 px-2 py-0.5 rounded uppercase">{post.type}</span>
                          <span className="text-[10px] text-gray-600 font-bold">{post.timestamp}</span>
                      </div>
                      <h4 className="font-black text-sm mb-2">{post.title}</h4>
                      <p className="text-xs text-gray-500 line-clamp-2 leading-relaxed">{post.content}</p>
                  </div>
              ))
          ) : (
              <div className="grid grid-cols-2 gap-4">
                  {userProfile.favorites.map(fav => (
                      <div key={fav.id} onClick={() => navigate(`/roadmap/${fav.id}`)} className="bg-card-dark border border-white/10 rounded-3xl overflow-hidden relative group cursor-pointer">
                          <img src={fav.imageUrl} className="w-full h-24 object-cover opacity-60 group-hover:opacity-100 transition-all" />
                          <div className="p-3">
                              <h5 className="text-[10px] font-black text-white truncate uppercase">{fav.title}</h5>
                              <p className="text-[9px] text-primary font-bold">{fav.investment}</p>
                          </div>
                      </div>
                  ))}
              </div>
          )}
      </div>
    </div>
  );
};

export default ProfileScreen;
