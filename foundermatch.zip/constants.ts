import { BusinessModel, UserProfile, SuccessStory, Badge, SprintGroup, RoadmapComment } from './types';

export const BUSINESSES: BusinessModel[] = [
  {
    id: '1',
    title: 'Agencia de Edición Short-form',
    category: 'Servicios Digitales',
    description: 'Especialízate en Reels/TikToks para marcas personales B2B. Alta demanda, inversión cero.',
    imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=800',
    matchScore: 98,
    investment: '$0',
    difficulty: 'Media',
    timeToRevenue: '3 semanas'
  },
  {
    id: '2',
    title: 'Newsletter Curada IA',
    category: 'Contenido',
    description: 'Crea una audiencia en un nicho técnico (ej. Logística) usando IA para resumir noticias.',
    imageUrl: 'https://images.unsplash.com/photo-1586339949916-3e9457bef6d3?auto=format&fit=crop&q=80&w=800',
    matchScore: 92,
    investment: '$20/mes',
    difficulty: 'Baja',
    timeToRevenue: '2 meses'
  },
  {
    id: '3',
    title: 'Micro-SaaS de Automatización',
    category: 'Software',
    description: 'Herramientas No-Code para inmobiliarias. Resuelve un problema de nicho muy específico.',
    imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=800',
    matchScore: 85,
    investment: '$50',
    difficulty: 'Alta',
    timeToRevenue: '4 meses'
  }
];

export const BADGES: Badge[] = [
  { id: 'b1', label: 'Llamada Real', icon: '📞' },
  { id: 'b2', label: 'Primer Cliente', icon: '🧾' },
  { id: 'b3', label: 'MVP Listo', icon: '🚀' },
  { id: 'b4', label: 'Mentor Activo', icon: '🧠' }
];

export const ROADMAP_COMMENTS: RoadmapComment[] = [
  { id: 'c1', userName: 'Marco_SaaS', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=100', text: 'No os compliquéis con la web, usad una landing de una sola página y validad.', isMentor: true, timestamp: '1h' },
  { id: 'c2', userName: 'Elena.Design', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=100', text: 'En este paso lo más difícil fue encontrar el email del CEO. Usad Apollo.io.', isMentor: false, timestamp: '5h' },
  { id: 'c3', userName: 'Carlos_Editor', avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?auto=format&fit=crop&q=80&w=100', text: 'Validado. Envié 20 mensajes y tengo 2 reuniones. ¡Funciona!', isMentor: false, timestamp: '1d' }
];

export const SPRINT_GROUPS: SprintGroup[] = [
  {
    id: 's1',
    name: 'Tribu Editores B2B',
    members: 5,
    activeNow: 2,
    image: 'https://images.unsplash.com/photo-1536240478700-b869070f9279?auto=format&fit=crop&q=80&w=200',
    category: 'Servicios',
    description: 'Grupo enfocado en conseguir los primeros 3 clientes de edición.',
    tags: ['Edición', 'Outbound'],
    sprintWeek: 2,
    daysRemaining: 3,
    maxMembers: 7,
    tribeMembers: [
      { id: 'm1', name: 'Alex', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=100', currentState: 'Validando' },
      { id: 'm2', name: 'Santi (Mentor)', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=100', currentState: 'Escalando', isMentor: true },
      { id: 'm3', name: 'Laura', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=100', currentState: 'Definiendo oferta' }
    ]
  }
];

export const DEFAULT_PROFILE: UserProfile = {
  name: "Alex Founder",
  handle: "@alex_builds",
  bio: "Buscando mi primer cliente como editor. No-code enthusiast.",
  avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200",
  level: 1,
  xp: 150,
  streak: 3,
  currentState: "Definiendo Oferta",
  availability: "Feedback",
  dailyNote: "Primeras 5 llamadas de prospección hechas. 0 éxitos, 1 aprendizaje.",
  badges: [BADGES[0]],
  interests: ["SaaS", "Edición", "Marketing"],
  myPosts: [],
  favorites: []
};

export const SUCCESS_STORIES: SuccessStory[] = [
  {
    id: 'st1',
    user: { name: 'Julian R.', handle: '@juli_editor', avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?auto=format&fit=crop&q=80&w=100' },
    title: 'Fracaso útil: Perdí mi primer cliente',
    description: 'No definí bien el alcance del proyecto. Aprendizaje: Siempre cobrar 50% por adelantado y firmar contrato simple.',
    metric: 'Aprendizaje',
    metricLabel: 'Lección Real',
    type: 'Milestone',
    reactions: { unblocked: 89, tried: 12, valuable: 156 },
    commentsCount: 23,
    timestamp: '4h'
  },
  {
    id: 'st2',
    user: { name: 'Marta G.', handle: '@marta_valida', avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=100' },
    title: 'Validación en 48h con $0',
    description: 'Publiqué mi oferta en un grupo de Facebook de dentistas. 5 leads calificados.',
    metric: '5 Leads',
    metricLabel: 'Acción',
    type: 'Growth',
    reactions: { unblocked: 34, tried: 120, valuable: 88 },
    commentsCount: 12,
    timestamp: '1d'
  }
];