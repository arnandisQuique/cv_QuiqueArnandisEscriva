export interface BusinessModel {
  id: string;
  title: string;
  category: string;
  description: string;
  imageUrl: string;
  matchScore: number;
  investment: string;
  difficulty: 'Baja' | 'Media' | 'Alta';
  timeToRevenue: string;
}

export interface GroupMember {
  id: string;
  name: string;
  avatar: string;
  currentState: string;
  isMentor?: boolean;
}

export interface CommunityGroup {
  id: string;
  name: string;
  members: number;
  activeNow: number;
  image: string;
  category: string;
  description: string;
  tags: string[];
  isJoined?: boolean;
}

export interface SprintGroup extends CommunityGroup {
  sprintWeek: number;
  daysRemaining: number;
  maxMembers: 7;
  tribeMembers: GroupMember[];
}

export interface RoadmapComment {
  id: string;
  userName: string;
  avatar: string;
  text: string;
  isMentor: boolean;
  timestamp: string;
}

export interface QuizState {
  capital: string;
  timeCommitment: string;
  interest: string;
}

export type PostStructureType = 'Feedback' | 'Partner' | 'Learning' | 'General';

export interface UserPost {
  id: string;
  type: PostStructureType;
  title: string;
  content: string;
  context?: string;
  reactions: {
    unblocked: number;
    tried: number;
    valuable: number;
  };
  timestamp: string;
}

export interface UserProfile {
  name: string;
  handle: string;
  bio: string;
  avatar: string;
  level: number;
  xp: number;
  streak: number;
  currentState: string;
  availability: 'Feedback' | 'Colaboración' | 'Cerrado';
  dailyNote?: string;
  badges: Badge[];
  interests: string[];
  myPosts: UserPost[];
  favorites: BusinessModel[];
}

export interface Badge {
  id: string;
  label: string;
  icon: string;
  unlockedAt?: string;
}

export interface SuccessStory {
  id: string;
  user: {
    name: string;
    avatar: string;
    handle: string;
  };
  title: string;
  description: string;
  metric: string;
  metricLabel: string;
  type: 'Revenue' | 'Growth' | 'Launch' | 'Milestone';
  reactions: {
    unblocked: number;
    tried: number;
    valuable: number;
  };
  commentsCount: number;
  timestamp: string;
}