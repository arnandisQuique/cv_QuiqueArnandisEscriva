import React, { createContext, useContext, useState } from 'react';
import { HashRouter, Routes, Route, useLocation, useNavigate } from 'react-router-dom';
import { Home, Compass, MessageCircle, User, Plus } from 'lucide-react';
import WelcomeScreen from './screens/WelcomeScreen';
import QuizScreen from './screens/QuizScreen';
import MatchScreen from './screens/MatchScreen';
import RoadmapScreen from './screens/RoadmapScreen';
import GroupsScreen from './screens/GroupsScreen';
import ProfileScreen from './screens/ProfileScreen';
import ExploreScreen from './screens/ExploreScreen';
import CreateScreen from './screens/CreateScreen';
import SprintDetailScreen from './screens/SprintDetailScreen';
import { QuizState, UserProfile } from './types';
import { DEFAULT_PROFILE } from './constants';

// Context for global state
interface AppContextType {
  quizState: QuizState;
  setQuizState: React.Dispatch<React.SetStateAction<QuizState>>;
  userProfile: UserProfile;
  setUserProfile: React.Dispatch<React.SetStateAction<UserProfile>>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error("useAppContext must be used within AppProvider");
  return context;
};

// Layout component for screens with bottom nav
const MainLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const navigate = useNavigate();
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="relative flex flex-col h-screen max-w-md mx-auto bg-background-dark overflow-hidden shadow-2xl">
      <div className="flex-1 overflow-y-auto no-scrollbar">
        {children}
      </div>
      
      {/* Bottom Navigation */}
      <nav className="shrink-0 h-20 bg-background-darker/90 backdrop-blur-lg border-t border-white/5 px-4 pb-6 pt-3 z-50">
        <div className="flex justify-between items-end h-full px-2">
          {/* Match */}
          <button 
            onClick={() => navigate('/match')}
            className={`flex flex-col items-center justify-end gap-1 flex-1 group cursor-pointer transition-colors ${isActive('/match') ? 'text-primary' : 'text-slate-500 hover:text-slate-300'}`}
          >
            <div className="relative">
              <Home size={24} strokeWidth={isActive('/match') ? 2.5 : 2} />
              {isActive('/match') && <span className="absolute -top-1 -right-1 size-2 bg-primary rounded-full animate-pulse shadow-neon" />}
            </div>
            <span className="text-[10px] font-medium">Match</span>
          </button>

          {/* Groups */}
          <button 
            onClick={() => navigate('/groups')}
            className={`flex flex-col items-center justify-end gap-1 flex-1 group cursor-pointer transition-colors ${isActive('/groups') || location.pathname.includes('/sprint/') ? 'text-primary' : 'text-slate-500 hover:text-slate-300'}`}
          >
             <div className="relative">
              <MessageCircle size={24} strokeWidth={isActive('/groups') || location.pathname.includes('/sprint/') ? 2.5 : 2} />
              <span className="absolute -top-1.5 -right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[9px] font-bold text-white shadow-sm">3</span>
            </div>
            <span className="text-[10px] font-medium">Sprints</span>
          </button>

          {/* CREATE BUTTON (CENTER) */}
          <div className="relative -top-5 flex justify-center flex-1">
            <button 
              onClick={() => navigate('/create')}
              className="flex items-center justify-center size-14 rounded-full bg-primary text-background-dark shadow-neon-strong hover:scale-105 active:scale-95 transition-all border-4 border-background-darker"
            >
              <Plus size={32} strokeWidth={3} />
            </button>
          </div>

          {/* Explore */}
          <button 
            onClick={() => navigate('/explore')}
            className={`flex flex-col items-center justify-end gap-1 flex-1 group cursor-pointer transition-colors ${isActive('/explore') ? 'text-primary' : 'text-slate-500 hover:text-slate-300'}`}
          >
            <div className="relative">
               <Compass size={24} strokeWidth={isActive('/explore') ? 2.5 : 2} />
            </div>
            <span className="text-[10px] font-medium">Acción</span>
          </button>

          {/* Profile */}
          <button 
            onClick={() => navigate('/profile')}
            className={`flex flex-col items-center justify-end gap-1 flex-1 group cursor-pointer transition-colors ${isActive('/profile') ? 'text-primary' : 'text-slate-500 hover:text-slate-300'}`}
          >
             <div className="relative">
                <User size={24} strokeWidth={isActive('/profile') ? 2.5 : 2} />
             </div>
            <span className="text-[10px] font-medium">Perfil</span>
          </button>
        </div>
      </nav>
    </div>
  );
};

const App: React.FC = () => {
  const [quizState, setQuizState] = useState<QuizState>({
    capital: '0-100',
    timeCommitment: 'Parcial',
    interest: 'Digital'
  });
  
  const [userProfile, setUserProfile] = useState<UserProfile>(DEFAULT_PROFILE);

  return (
    <AppContext.Provider value={{ quizState, setQuizState, userProfile, setUserProfile }}>
      <HashRouter>
        <Routes>
          <Route path="/" element={<WelcomeScreen />} />
          <Route path="/quiz" element={<QuizScreen />} />
          <Route path="/match" element={<MainLayout><MatchScreen /></MainLayout>} />
          <Route path="/groups" element={<MainLayout><GroupsScreen /></MainLayout>} />
          <Route path="/sprint/:id" element={<MainLayout><SprintDetailScreen /></MainLayout>} />
          <Route path="/explore" element={<MainLayout><ExploreScreen /></MainLayout>} />
          <Route path="/create" element={<CreateScreen />} />
          <Route path="/profile" element={<MainLayout><ProfileScreen /></MainLayout>} />
          <Route path="/roadmap/:id" element={<RoadmapScreen />} />
        </Routes>
      </HashRouter>
    </AppContext.Provider>
  );
};

export default App;